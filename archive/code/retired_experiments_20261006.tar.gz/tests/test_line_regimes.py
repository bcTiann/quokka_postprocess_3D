from __future__ import annotations

import unittest

import numpy as np

from quokka2s.constants import BOLTZMANN_ERG_K, HYDROGEN_MASS_G
from quokka2s.physics.temperature_regimes import HELIUM_MASS_FRACTION, HYDROGEN_MASS_FRACTION, MEAN_METAL_ATOMIC_WEIGHT, METAL_MASS_FRACTION, electron_fraction_from_mean_molecular_weight, emitter_temperature_field_name, temperature_regime_masks


class LineRegimeTests(unittest.TestCase):
    def test_default_composition_follows_cloudy_definition(self):
        expected_X = 1.0 / (1.0 + 0.1 * 3.971)
        self.assertAlmostEqual(HYDROGEN_MASS_FRACTION, expected_X)
        self.assertAlmostEqual(METAL_MASS_FRACTION, 0.02)
        self.assertAlmostEqual(
            HELIUM_MASS_FRACTION,
            1.0 - expected_X - METAL_MASS_FRACTION,
        )
        self.assertAlmostEqual(MEAN_METAL_ATOMIC_WEIGHT, 16.0)
        self.assertAlmostEqual(
            HYDROGEN_MASS_FRACTION
            + HELIUM_MASS_FRACTION
            + METAL_MASS_FRACTION,
            1.0,
        )

    def test_emitter_temperature_policy(self):
        self.assertEqual(
            emitter_temperature_field_name('CO'),
            'temperature_despotic',
        )
        self.assertEqual(
            emitter_temperature_field_name('CO21'),
            'temperature_despotic',
        )
        self.assertEqual(
            emitter_temperature_field_name('C+'),
            'temperature_quokka',
        )
        with self.assertRaises(ValueError):
            emitter_temperature_field_name('unknown')

    def test_boundary_membership(self):
        despotic_cutoff = 3000.0
        cie_cutoff = 1.307e4
        temperature = np.array([
            despotic_cutoff - 1.0,
            despotic_cutoff,
            cie_cutoff - 1.0,
            cie_cutoff,
        ])
        low, intermediate, high = temperature_regime_masks(
            temperature,
            despotic_cutoff,
            cie_cutoff,
        )
        np.testing.assert_array_equal(low, [True, False, False, False])
        np.testing.assert_array_equal(intermediate, [False, True, True, False])
        np.testing.assert_array_equal(high, [False, False, False, True])

    def test_mean_molecular_weight_inversion_recovers_xe(self):
        X, Y = HYDROGEN_MASS_FRACTION, HELIUM_MASS_FRACTION
        gamma = 5.0 / 3.0
        rho = np.array([1.0e-24, 2.0e-24, 3.0e-24])
        temperature = np.array([4000.0, 8000.0, 12000.0])
        expected_xe = np.array([0.0, 0.25, 1.0])
        inverse_mu = X + Y / 4.0 + X * expected_xe
        e_int = (inverse_mu * rho * BOLTZMANN_ERG_K * temperature
                 / ((gamma - 1.0) * HYDROGEN_MASS_G))

        actual = electron_fraction_from_mean_molecular_weight(
            e_int,
            rho,
            temperature,
        )
        np.testing.assert_allclose(actual, expected_xe, rtol=1e-13, atol=1e-13)

    def test_legacy_mean_molecular_weight_name_is_nonnegative_alias(self):
        e_int = np.array([0.1, 1.0, 10.0])
        rho = np.ones(3)
        temperature = np.ones(3)
        actual = electron_fraction_from_mean_molecular_weight(
            e_int,
            rho,
            temperature,
        )
        expected = electron_fraction_from_mean_molecular_weight(
            e_int,
            rho,
            temperature,
        )
        np.testing.assert_array_equal(actual, expected)

    def test_total_electron_fraction_applies_only_nonnegative_floor(self):
        X, Y = HYDROGEN_MASS_FRACTION, HELIUM_MASS_FRACTION
        gamma = 5.0 / 3.0
        rho = np.full(4, 2.0e-24)
        temperature = np.array([3000.0, 8000.0, 2.0e4, 1.0e6])
        raw_xe = np.array([-0.5, 0.4, 1.1, 2.0])
        expected_xe = np.maximum(raw_xe, 0.0)
        inverse_mu = X + Y / 4.0 + X * raw_xe
        e_int = (inverse_mu * rho * BOLTZMANN_ERG_K * temperature
                 / ((gamma - 1.0) * HYDROGEN_MASS_G))

        actual = electron_fraction_from_mean_molecular_weight(
            e_int,
            rho,
            temperature,
        )

        np.testing.assert_allclose(actual, expected_xe, rtol=1e-13, atol=1e-13)

    def test_metal_nucleus_term_is_omitted_from_eos_inversion(self):
        X, Y = 0.70, 0.28
        inverse_mu_without_electrons = X + Y / 4.0
        rho = np.array([1.0e-24])
        temperature = np.array([100.0])
        e_int = (
            inverse_mu_without_electrons * rho * BOLTZMANN_ERG_K * temperature
            / ((5.0 / 3.0 - 1.0) * HYDROGEN_MASS_G)
        )

        actual = electron_fraction_from_mean_molecular_weight(
            e_int,
            rho,
            temperature,
            X=X,
            Y=Y,
        )

        np.testing.assert_allclose(actual, [0.0], atol=1e-15)

if __name__ == "__main__":
    unittest.main()
