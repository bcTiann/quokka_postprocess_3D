#!/usr/bin/env python3
"""Compare the full-snapshot intrinsic and dust-attenuated LOS-z spectra."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np

from quokka2s.products.integrated_spectra import LINE_TITLES


PLOT_ORDER = (
    "halpha", "hi21", "cii", "ciii_977", "ciii_1907",
    "ciii_1909", "civ_1548", "civ_1551", "co10", "co21",
)
SHORT_VELOCITY_RANGE = {"cii", "co10", "co21"}


def load_checked_pair(intrinsic_path: Path, attenuated_path: Path):
    with np.load(intrinsic_path, allow_pickle=False) as intrinsic, np.load(
        attenuated_path, allow_pickle=False
    ) as attenuated:
        required = ("line_keys", "velocity_kms", "velocity_edges_kms",
                    "total_dL_dv_erg_s_per_kms", "input_luminosity_erg_s",
                    "captured_luminosity_erg_s", "projected_area_cm2",
                    "source_manifest_sha256", "full_snapshot", "line_of_sight")
        for name in required:
            if name not in intrinsic or name not in attenuated:
                raise ValueError(f"Missing spectrum field: {name}")
        for name in ("line_keys", "velocity_kms", "velocity_edges_kms",
                     "projected_area_cm2", "source_manifest_sha256", "line_of_sight"):
            if not np.array_equal(intrinsic[name], attenuated[name]):
                raise ValueError(f"Intrinsic and attenuated spectra differ in {name}")
        if (not bool(intrinsic["full_snapshot"]) or not bool(attenuated["full_snapshot"])
                or str(intrinsic["line_of_sight"]) != "z"
                or not bool(attenuated["dust_applied"])):
            raise ValueError("Expected matched full-snapshot z spectra with dust in the second input")
        keys = tuple(str(key) for key in intrinsic["line_keys"])
        if set(keys) != set(PLOT_ORDER):
            raise ValueError("Unexpected adopted line inventory")
        intrinsic_spectra = np.asarray(intrinsic["total_dL_dv_erg_s_per_kms"], dtype=float)
        attenuated_spectra = np.asarray(attenuated["total_dL_dv_erg_s_per_kms"], dtype=float)
        intrinsic_input = np.asarray(intrinsic["input_luminosity_erg_s"], dtype=float).sum(axis=1)
        attenuated_input = np.asarray(attenuated["input_luminosity_erg_s"], dtype=float).sum(axis=1)
        intrinsic_captured = np.asarray(intrinsic["captured_luminosity_erg_s"], dtype=float).sum(axis=1)
        attenuated_captured = np.asarray(attenuated["captured_luminosity_erg_s"], dtype=float).sum(axis=1)
        if (intrinsic_spectra.shape != attenuated_spectra.shape
                or intrinsic_spectra.shape != (len(keys), len(intrinsic["velocity_kms"]))
                or not np.isfinite(intrinsic_spectra).all()
                or not np.isfinite(attenuated_spectra).all()
                or np.any(attenuated_spectra > intrinsic_spectra*(1.+1.e-11))):
            raise ValueError("Dust spectra must be finite and no brighter than intrinsic spectra")
        if not np.array_equal(intrinsic_spectra[keys.index("hi21")],
                              attenuated_spectra[keys.index("hi21")]):
            raise ValueError("H I 21 cm should be exactly unchanged")
        return dict(keys=keys, velocity=np.asarray(intrinsic["velocity_kms"], dtype=float),
                    area=float(intrinsic["projected_area_cm2"]),
                    intrinsic_spectra=intrinsic_spectra, attenuated_spectra=attenuated_spectra,
                    intrinsic_input=intrinsic_input, attenuated_input=attenuated_input,
                    intrinsic_captured=intrinsic_captured, attenuated_captured=attenuated_captured)


def draw_axis(axis, velocity, intrinsic, attenuated, key):
    if key == "hi21":
        axis.plot(velocity, intrinsic, color="#242424", lw=1.8,
                  label="Dust attenuation not applied")
    else:
        axis.plot(velocity, intrinsic, color="#242424", lw=1.5, ls="--", label="No dust", zorder=3)
        axis.plot(velocity, attenuated, color="#C53D46", lw=1.8, label="With dust", zorder=2)
    axis.set_xlim((-100., 100.) if key in SHORT_VELOCITY_RANGE else (-200., 200.))
    axis.set_ylim(bottom=0.)
    axis.ticklabel_format(axis="y", style="sci", scilimits=(-2, 2), useMathText=True)
    axis.grid(alpha=.18)
    axis.legend(frameon=False, fontsize=8, loc="upper right")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--intrinsic", required=True, type=Path)
    parser.add_argument("--attenuated", required=True, type=Path)
    parser.add_argument("--output-dir", required=True, type=Path)
    args = parser.parse_args()
    data = load_checked_pair(args.intrinsic, args.attenuated)
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    args.output_dir.mkdir(parents=True, exist_ok=True)
    indices = {key: data["keys"].index(key) for key in PLOT_ORDER}
    velocity, area = data["velocity"], data["area"]
    figure, axes = plt.subplots(5, 2, figsize=(11.5, 13), sharex=False)
    for key, axis in zip(PLOT_ORDER, axes.flat):
        idx = indices[key]
        draw_axis(axis, velocity, data["intrinsic_spectra"][idx]/area,
                  data["attenuated_spectra"][idx]/area, key)
        axis.set_title(LINE_TITLES[key], fontsize=10.5)
        axis.set_xlabel(r"$v_z$ [km s$^{-1}$]")
    figure.supylabel(r"$d\Sigma_L/dv$ [erg s$^{-1}$ cm$^{-2}$ (km s$^{-1}$)$^{-1}$]")
    figure.tight_layout(rect=(.025, 0., 1., 1.))
    for extension in ("pdf", "png"):
        figure.savefig(args.output_dir/f"dust_spectrum_comparison_all.{extension}",
                       dpi=200, bbox_inches="tight")
    plt.close(figure)

    for key in PLOT_ORDER:
        idx = indices[key]
        figure, axis = plt.subplots(figsize=(6.2, 3.5))
        draw_axis(axis, velocity, data["intrinsic_spectra"][idx]/area,
                  data["attenuated_spectra"][idx]/area, key)
        axis.set_xlabel(r"$v_z$ [km s$^{-1}$]")
        axis.set_ylabel(r"$d\Sigma_L/dv$ [erg s$^{-1}$ cm$^{-2}$ (km s$^{-1}$)$^{-1}$]")
        figure.tight_layout()
        stem = ("hi21_dust_attenuation_not_applied" if key == "hi21"
                else f"{key}_dust_vs_no_dust")
        for extension in ("pdf", "png"):
            figure.savefig(args.output_dir/f"{stem}.{extension}",
                           dpi=200, bbox_inches="tight")
        plt.close(figure)

    summary = {}
    for key in PLOT_ORDER:
        idx = indices[key]
        input_ratio = data["attenuated_input"][idx]/data["intrinsic_input"][idx]
        captured_ratio = data["attenuated_captured"][idx]/data["intrinsic_captured"][idx]
        peak_ratio = data["attenuated_spectra"][idx].max()/data["intrinsic_spectra"][idx].max()
        summary[key] = dict(intrinsic_input_luminosity_erg_s=float(data["intrinsic_input"][idx]),
                            attenuated_input_luminosity_erg_s=float(data["attenuated_input"][idx]),
                            dust_attenuation_applied=(key != "hi21"),
                            transmitted_input_fraction=float(input_ratio),
                            transmitted_captured_fraction=float(captured_ratio),
                            attenuated_to_intrinsic_peak=float(peak_ratio))
    (args.output_dir/"comparison_summary.json").write_text(json.dumps(summary, indent=2)+"\n")
    print(json.dumps({key: row["transmitted_captured_fraction"] for key, row in summary.items()}, indent=2))


if __name__ == "__main__":
    main()
