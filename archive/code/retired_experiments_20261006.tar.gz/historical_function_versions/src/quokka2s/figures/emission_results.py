"""Plot saved line-luminosity images, integrated spectra, and gas phases.

The plotting stage reads only the three processed ``.npz`` products. It never
opens a simulation snapshot or recalculates an emissivity or line profile.
Run it with ``python -m quokka2s.plot_emission_results --config emission_plot.yaml``.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import numpy as np

from quokka2s.products.integrated_spectra import LINE_TITLES
from quokka2s.products import DUST_STATES
from quokka2s.figures.gas_phase_spectra import (
    GasPhaseVelocityProfiles,
    LINE_ORDER,
    LineSpectraForComparison,
    plot_phase_spectrum_overlay,
)

SHORT_VELOCITY_LIMITS_KMS = (-50.0, 50.0)


def read_product_arrays(path: Path, required: tuple[str, ...]) -> dict[str, np.ndarray]:
    """Read selected arrays from a processed NPZ file.

    Parameters
    ----------
    path : pathlib.Path
        Product file written by the process command.
    required : tuple of str
        Field names to load.

    Returns
    -------
    dict of str to numpy.ndarray
        Independent array copies, usable after the file is closed.
    """
    with np.load(path, allow_pickle=False) as data:
        return {key: data[key].copy() for key in required}


def load_emission_products(products_dir: str | Path) -> tuple[dict, dict]:
    """Read the saved fields needed to draw images and spectra.

    Parameters
    ----------
    products_dir : str or pathlib.Path
        Directory containing images.npz and spectra.npz from process.

    Returns
    -------
    images, spectra : tuple of dict
        Images (2, L, nx, ny) [erg/s per pixel] and spectra (2, L, 2, V)
        [erg/s/(km/s)], with their plotting coordinates. Axis 0 is intrinsic,
        then attenuated; the spectrum's third axis is cold, then hot.
        Process checks the numerical products before saving them.

    Examples
    --------
    ``images, spectra = load_emission_products(products_dir)``.
    ``images["line_luminosity_image_erg_s"][0]`` contains intrinsic images.
    """
    directory = Path(products_dir)
    images = read_product_arrays(
        path=directory / "images.npz",
        required=(
            "line_keys",
            "line_luminosity_image_erg_s",
            "x_edges_kpc",
            "y_edges_kpc",
            "full_snapshot",
        ),
    )
    spectra = read_product_arrays(
        path=directory / "spectra.npz",
        required=(
            "velocity_kms",
            "dL_dv_erg_s_per_kms",
            "projected_area_cm2",
            "line_centroid_window_kms",
            "line_sigma_full_kms",
        ),
    )
    return images, spectra


def load_phase_velocity_products(products_dir: str | Path) -> dict:
    """Read the saved gas profiles and dispersions used in comparison figures.

    Parameters
    ----------
    products_dir : str or pathlib.Path
        Process output directory containing phase_velocity.npz.

    Returns
    -------
    dict of str to numpy.ndarray
        histogram_mass_g (6, V) [g per channel] and two dispersion arrays
        (6,) [km/s]. Rows are CNM, UNM, WNM, WIM, HIM, then all gas.

    Examples
    --------
    ``phase = load_phase_velocity_products(products_dir)``.
    ``phase["histogram_mass_g"][-1]`` is the all-gas velocity profile.
    """
    return read_product_arrays(
        path=Path(products_dir) / "phase_velocity.npz",
        required=(
            "histogram_mass_g",
            "sigma_about_global_mean_kms",
            "sigma_internal_kms",
        ),
    )


def combine_image_pixels_for_display(
    images: dict,
    factor: int,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Sum neighbouring luminosity pixels for display.

    Parameters
    ----------
    images : dict
        load_emission_products() image output: (2, L, nx, ny) [erg/s] and
        x/y pixel edges [kpc].
    factor : int
        Pixels combined along each axis; 1 retains the original arrays.

    Returns
    -------
    values, x_edges, y_edges : tuple of numpy.ndarray
        Images (2, L, nx/factor, ny/factor) [erg/s per new pixel] and matching
        edges [kpc]. Pixel luminosities are summed, not averaged.

    Examples
    --------
    With loaded images, combine 2 by 2 native pixels::

        values, x_edges, y_edges = combine_image_pixels_for_display(images, 2)
    """
    values = images["line_luminosity_image_erg_s"]
    nx, ny = values.shape[-2:]
    if type(factor) is not int or factor <= 0:
        raise ValueError("image_downsample_factor must be a positive integer")
    if nx % factor or ny % factor:
        raise ValueError("image_downsample_factor must divide both image dimensions")
    if factor == 1:
        return values, images["x_edges_kpc"], images["y_edges_kpc"]
    # Split each x/y axis into coarse pixels and the native pixels inside them.
    # Example: factor=2 changes (2, 10, 256, 256) into (2, 10, 128, 2, 128, 2).
    grouped_pixels = values.reshape(
        *values.shape[:2],
        nx // factor,
        factor,
        ny // factor,
        factor,
    )
    binned = grouped_pixels.sum(axis=(3, 5))
    x_edges = images["x_edges_kpc"][::factor]
    y_edges = images["y_edges_kpc"][::factor]
    return binned, x_edges, y_edges


def save_figure_formats(figure, stem: Path, formats: tuple[str, ...]) -> list[Path]:
    """Write a Matplotlib figure in each requested format.

    Parameters
    ----------
    figure : matplotlib.figure.Figure
        Completed figure from a plotting function.
    stem : pathlib.Path
        Output path before the file extension; its directory must exist.
    formats : tuple of str
        Extensions such as ("png", "pdf").

    Returns
    -------
    list of pathlib.Path
        Written figure paths, in format order.
    """
    paths = []
    for extension in formats:
        path = stem.with_suffix("." + extension)
        figure.savefig(path, dpi=200, bbox_inches="tight")
        paths.append(path)
    return paths


def plot_line_images(
    keys,
    image_values,
    x_edges,
    y_edges,
    output: Path,
    *,
    diagnostic_suffix: str,
    titled: bool,
    formats: tuple[str, ...],
) -> list[Path]:
    """Draw intrinsic and attenuated images with each line's shared colour scale.

    Parameters
    ----------
    keys : tuple of str, length L
        Saved line order from load_emission_products().
    image_values : numpy.ndarray, shape (2, L, nx, ny)
        Luminosities [erg/s per pixel] from combine_image_pixels_for_display().
        Dust state 0 is intrinsic and state 1 is attenuated.
    x_edges, y_edges : numpy.ndarray, shapes (nx + 1,), (ny + 1,)
        Display pixel boundaries [kpc] from the same function.
    output : pathlib.Path
        Figure destination.
    diagnostic_suffix : str
        Empty for full-snapshot products, otherwise "_partial_diagnostic".
    titled : bool
        Include the line name and dust state in each figure title.
    formats : tuple of str
        Output extensions, normally ("png", "pdf").

    Returns
    -------
    list of pathlib.Path
        Two figures per line, except one for HI where dust extinction is zero.
        Each line uses limits (maximum / 1e5, maximum) across its two images.

    Examples
    --------
    ``image_values[0, keys.index('halpha')]`` supplies the intrinsic Halpha
    image; its x/y axes are transposed only when passed to Matplotlib.
    """
    import matplotlib.pyplot as plt
    from matplotlib.colors import LogNorm

    image_paths = []
    for line_index, key in enumerate(keys):
        pair = image_values[:, line_index]
        vmax = float(pair.max())
        norm = None
        if vmax > 0:
            norm = LogNorm(vmin=vmax / 1e5, vmax=vmax)
        image_dust_states = tuple(enumerate(DUST_STATES))
        if key == "hi21":
            # HI has no dust treatment: write one image without a dust-state suffix.
            image_dust_states = ((0, ""),)
        for dust_index, dust_state in image_dust_states:
            figure = create_line_luminosity_image(
                luminosity_image_erg_s=pair[dust_index],
                x_edges_kpc=x_edges,
                y_edges_kpc=y_edges,
                color_scale=norm,
                line_key=key,
                dust_state=dust_state,
                titled=titled,
            )
            image_stem = f"line_luminosity_{key}"
            if dust_state:
                image_stem += f"_{dust_state}"
            image_paths.extend(save_figure_formats(
                figure=figure,
                stem=output / (image_stem + diagnostic_suffix),
                formats=formats,
            ))
            plt.close(figure)
    return image_paths


def create_line_luminosity_image(
    luminosity_image_erg_s: np.ndarray,
    x_edges_kpc: np.ndarray,
    y_edges_kpc: np.ndarray,
    color_scale,
    line_key: str,
    dust_state: str,
    titled: bool,
):
    """Draw one line's x-y image using its shared intrinsic/attenuated scale.

    Parameters
    ----------
    luminosity_image_erg_s : numpy.ndarray, shape (nx, ny)
        One dust state's displayed luminosity [erg/s per pixel].
    x_edges_kpc, y_edges_kpc : numpy.ndarray, shapes (nx + 1,), (ny + 1,)
        Pixel boundaries [kpc] from combine_image_pixels_for_display().
    color_scale : matplotlib.colors.LogNorm or None
        The line's paired colour limits; None means both images are zero.
    line_key, dust_state : str
        Transition name and "intrinsic"/"attenuated"; HI uses an empty state.
    titled : bool
        Include the standalone line/dust title.

    Returns
    -------
    matplotlib.figure.Figure
        Figure ready for save_figure_formats(). Plotting transposes (x, y)
        to Matplotlib's row/column convention without changing saved arrays.
    """
    import matplotlib.pyplot as plt

    figure, axis = plt.subplots(figsize=(5.2, 4.5))
    image = luminosity_image_erg_s.T  # Matplotlib rows=y, columns=x.
    if color_scale is None:
        axis.set_facecolor("white")
        axis.text(
            0.5,
            0.5,
            "No emission",
            ha="center",
            va="center",
            transform=axis.transAxes,
        )
    else:
        mesh = axis.pcolormesh(
            x_edges_kpc,
            y_edges_kpc,
            np.ma.masked_less_equal(image, 0.0),
            cmap="magma",
            norm=color_scale,
            shading="flat",
        )
    axis.set_xlabel("x [kpc]")
    axis.set_ylabel("y [kpc]")
    axis.set_xlim(x_edges_kpc[[0, -1]])
    axis.set_ylim(y_edges_kpc[[0, -1]])
    axis.set_aspect("equal")
    if titled:
        title = LINE_TITLES[line_key]
        if dust_state == "intrinsic":
            title += " — Intrinsic"
        elif dust_state == "attenuated":
            title += " — Dust attenuated"
        axis.set_title(title)
    if color_scale is not None:
        figure.colorbar(mesh, ax=axis, label=r"Pixel luminosity [erg s$^{-1}$]")
    figure.tight_layout()
    return figure


def prepare_total_line_spectra(
    spectra: dict,
    per_projected_area: bool,
) -> tuple[np.ndarray, str]:
    """Sum cold/hot profiles and prepare the plotted physical units.

    Parameters
    ----------
    spectra : dict of str to numpy.ndarray
        Saved spectra.npz arrays from load_emission_products().
    per_projected_area : bool
        Divide each spectrum by projected_area_cm2 when True.

    Returns
    -------
    total_profiles : numpy.ndarray, shape (2, L, 400)
        Intrinsic and attenuated total spectra [erg/s/(km/s)], or
        [erg/s/cm^2/(km/s)] when normalized by the projected area.
    ylabel : str
        Axis label matching the selected units.
    """
    if per_projected_area:
        area = float(spectra["projected_area_cm2"])
        ylabel = r"$d\Sigma_L/dv$ [erg s$^{-1}$ cm$^{-2}$ (km s$^{-1}$)$^{-1}$]"
    else:
        area = 1.0
        ylabel = r"$dL/dv$ [erg s$^{-1}$ (km s$^{-1}$)$^{-1}$]"
    total_profiles = spectra["dL_dv_erg_s_per_kms"].sum(axis=2) / area
    return total_profiles, ylabel


def plot_line_spectra(
    keys,
    spectra: dict,
    output: Path,
    *,
    per_projected_area: bool,
    diagnostic_suffix: str,
    titled: bool,
    formats: tuple[str, ...],
) -> list[Path]:
    """Draw intrinsic and attenuated spectra summed over cold and hot cells.

    Parameters
    ----------
    keys : tuple of str, length L
        Saved line order from load_emission_products().
    spectra : dict of str to numpy.ndarray
        Saved spectra.npz arrays. Profiles have shape (2, L, 2, 400)
        [erg/s/(km/s)]; channel centres are in km/s.
    output : pathlib.Path
        Figure destination.
    per_projected_area : bool
        Divide by saved projected_area_cm2 when True; dust states are unchanged.
    diagnostic_suffix : str
        Empty for full-snapshot products, otherwise "_partial_diagnostic".
    titled : bool
        Include the line name above each figure.
    formats : tuple of str
        Output extensions, normally ("png", "pdf").

    Returns
    -------
    list of pathlib.Path
        One figure per line and format, showing only +/-50 km/s while keeping
        the full saved spectra unchanged. HI has one curve because its dust
        extinction is zero.

    Examples
    --------
    ``spectra['dL_dv_erg_s_per_kms'][1, keys.index('halpha')].sum(axis=0)``
    is the dust-attenuated Halpha curve before optional area normalization.
    """
    import matplotlib.pyplot as plt

    spectrum_paths = []
    velocity = spectra["velocity_kms"]
    total_profiles, ylabel = prepare_total_line_spectra(
        spectra=spectra,
        per_projected_area=per_projected_area,
    )

    for line_index, key in enumerate(keys):
        figure, axis = plt.subplots(figsize=(6.2, 3.5))
        intrinsic = total_profiles[0, line_index]
        attenuated = total_profiles[1, line_index]
        if key == "hi21":
            axis.plot(velocity, intrinsic, color="#242424", lw=1.8)
        else:
            axis.plot(velocity, intrinsic, color="#242424", lw=1.5, ls="--",
                      label="Intrinsic")
            axis.plot(velocity, attenuated, color="#C53D46", lw=1.8,
                      label="Dust attenuated")
            axis.legend(frameon=False, fontsize=9)
        axis.set_xlim(*SHORT_VELOCITY_LIMITS_KMS)
        axis.set_ylim(bottom=0)
        axis.set_xlabel(r"$v_z$ [km s$^{-1}$]")
        axis.set_ylabel(ylabel)
        if titled:
            axis.set_title(LINE_TITLES[key])
        axis.ticklabel_format(axis="y", style="sci", scilimits=(-2, 2), useMathText=True)
        axis.grid(alpha=0.18)
        figure.tight_layout()
        spectrum_paths.extend(save_figure_formats(
            figure=figure,
            stem=output / f"spectrum_{key}{diagnostic_suffix}",
            formats=formats,
        ))
        plt.close(figure)
    return spectrum_paths


def plot_gas_phase_comparisons(
    keys,
    spectra: dict,
    phase: dict,
    output: Path,
    *,
    diagnostic_suffix: str,
    titled: bool,
    formats: tuple[str, ...],
) -> list[Path]:
    """Draw gas histograms beside saved dust-attenuated line spectra.

    Parameters
    ----------
    keys : tuple of str, length L
        Saved line order from load_emission_products().
    spectra, phase : dict of str to numpy.ndarray
        Saved spectra.npz and phase_velocity.npz arrays from the loaders.
        Their coordinates, profiles, and dispersion arrays are passed directly
        to the renderer; no duplicate total profiles or nested reports are built.
    output : pathlib.Path
        Figure destination.
    diagnostic_suffix : str
        Empty for a complete snapshot, otherwise "_partial_diagnostic".
    titled : bool
        Include the standalone title and phase-cut footer.
    formats : tuple of str
        Output extensions, normally ("png", "pdf").

    Returns
    -------
    list of pathlib.Path
        Ten line figures per format, in LINE_ORDER.

    Examples
    --------
    The Halpha curve comes from ``spectra["dL_dv_erg_s_per_kms"][1]``:
    dust state 1 is attenuated, and the renderer sums its cold and hot profiles.
    """
    line_spectra = LineSpectraForComparison(
        line_keys=tuple(keys),
        velocity_kms=spectra["velocity_kms"],
        dL_dv_erg_s_per_kms=spectra["dL_dv_erg_s_per_kms"][1],
        line_centroid_window_kms=spectra["line_centroid_window_kms"][1],
        line_sigma_full_kms=spectra["line_sigma_full_kms"][1],
    )
    gas_phases = GasPhaseVelocityProfiles(
        histogram_mass_g=phase["histogram_mass_g"],
        sigma_about_global_mean_kms=phase["sigma_about_global_mean_kms"],
        sigma_internal_kms=phase["sigma_internal_kms"],
    )
    phase_stem = output / f"gas_phase_spectrum{diagnostic_suffix}"
    plot_phase_spectrum_overlay(
        line_spectra=line_spectra,
        gas_phases=gas_phases,
        output_stem=phase_stem,
        line_keys=LINE_ORDER,
        figure_style="full" if titled else "latex",
        formats=formats,
    )
    phase_paths = []
    for key in LINE_ORDER:
        line_stem = phase_stem.with_name(f"{phase_stem.name}_{key}")
        for extension in formats:
            phase_paths.append(line_stem.with_suffix("." + extension))
    return phase_paths


@dataclass(frozen=True)
class SavedEmissionProducts:
    """The three processed numerical files shared by all figure versions.

    Attributes
    ----------
    images : dict of str to numpy.ndarray
        images.npz from load_emission_products(). Luminosities have shape
        (2, 10, 256, 256) [erg/s per pixel]; x/y edges are in kpc.
    spectra : dict of str to numpy.ndarray
        spectra.npz from load_emission_products(). Profiles have shape
        (2, 10, 2, 400) [erg/s/(km/s)], with saved channel centres and
        full-profile line dispersions [km/s].
    gas_phases : dict of str to numpy.ndarray
        phase_velocity.npz from load_phase_velocity_products(). Histograms
        have shape (6, 400) [g per channel], with dispersions [km/s].

    Examples
    --------
    ``products.images["line_luminosity_image_erg_s"][0, 0]`` is the first
    line's intrinsic x-y image. Axis 0 is intrinsic, then attenuated.
    """

    images: dict[str, np.ndarray]
    spectra: dict[str, np.ndarray]
    gas_phases: dict[str, np.ndarray]


def load_plot_products(products_dir: str | Path) -> SavedEmissionProducts:
    """Read the image, spectrum, and gas-phase products once for plotting.

    Parameters
    ----------
    products_dir : str or pathlib.Path
        Directory containing the three NPZ files written by process.

    Returns
    -------
    SavedEmissionProducts
        Saved arrays; see the class for shapes and units.
        The loaded arrays can be reused for paper and titled figure versions.

    Examples
    --------
    ``products = load_plot_products("output/plt0655228/processed")``.
    Plotting never opens the snapshot or the emission lookup tables.
    """
    images, spectra = load_emission_products(products_dir)
    gas_phases = load_phase_velocity_products(
        products_dir=products_dir,
    )
    return SavedEmissionProducts(
        images=images,
        spectra=spectra,
        gas_phases=gas_phases,
    )


def draw_emission_products(
    products: SavedEmissionProducts,
    output_dir: str | Path,
    *,
    per_projected_area: bool = True,
    formats: tuple[str, ...] = ("png", "pdf"),
    allow_partial: bool = False,
    titled: bool = False,
    image_downsample_factor: int = 1,
) -> dict[str, list[Path]]:
    """Draw one figure version from already loaded numerical products.

    Parameters
    ----------
    products : SavedEmissionProducts
        The result of load_plot_products(); shared by paper and titled figures.
    output_dir : str or pathlib.Path
        Destination for this figure version.
    per_projected_area : bool
        Divide spectra by the saved area when True [erg/s/cm^2/(km/s)].
        Otherwise show luminosity spectra [erg/s/(km/s)]. This changes units,
        not the dust state; gas-phase comparisons always use attenuated lines.
    formats : tuple of str
        Output extensions, normally ("png", "pdf").
    allow_partial, titled : bool
        Permit diagnostic subsets; include standalone titles.
    image_downsample_factor : int
        Pixels summed along each x/y axis for display; 1 retains native pixels.

    Returns
    -------
    dict of str to list of pathlib.Path
        Figure paths grouped as images, spectra, and gas_phases.

    Examples
    --------
    ``draw_emission_products(products, figure_dir, titled=True)`` reuses the
    loaded arrays without reading files again or recalculating emission.
    """
    if not formats or any(extension not in ("png", "pdf") for extension in formats):
        raise ValueError("formats must contain png and/or pdf")
    images = products.images
    spectra = products.spectra
    phase = products.gas_phases
    full_snapshot = bool(images["full_snapshot"])
    if not full_snapshot and not allow_partial:
        raise ValueError("Partial diagnostic products require allow_partial=True")
    diagnostic_suffix = ""
    if not full_snapshot:
        diagnostic_suffix = "_partial_diagnostic"

    import matplotlib
    matplotlib.use("Agg")

    output = Path(output_dir)
    output.mkdir(parents=True, exist_ok=True)
    keys = tuple(str(key) for key in images["line_keys"])
    image_values, x_edges, y_edges = combine_image_pixels_for_display(
        images=images,
        factor=image_downsample_factor,
    )

    image_paths = plot_line_images(
        keys=keys,
        image_values=image_values,
        x_edges=x_edges,
        y_edges=y_edges,
        output=output,
        diagnostic_suffix=diagnostic_suffix,
        titled=titled,
        formats=formats,
    )
    spectrum_paths = plot_line_spectra(
        keys=keys,
        spectra=spectra,
        output=output,
        per_projected_area=per_projected_area,
        diagnostic_suffix=diagnostic_suffix,
        titled=titled,
        formats=formats,
    )
    phase_paths = plot_gas_phase_comparisons(
        keys=keys,
        spectra=spectra,
        phase=phase,
        output=output,
        diagnostic_suffix=diagnostic_suffix,
        titled=titled,
        formats=formats,
    )
    return {
        "images": image_paths,
        "spectra": spectrum_paths,
        "gas_phases": phase_paths,
    }


def plot_emission_products(
    products_dir: str | Path,
    output_dir: str | Path,
    *,
    per_projected_area: bool = True,
    formats: tuple[str, ...] = ("png", "pdf"),
    allow_partial: bool = False,
    titled: bool = False,
    image_downsample_factor: int = 1,
) -> dict[str, list[Path]]:
    """Read saved products and draw line images, spectra, and gas comparisons.

    Parameters
    ----------
    products_dir, output_dir : str or pathlib.Path
        Input directory with the three process NPZ files; figure destination.
    per_projected_area : bool
        Show spectra per projected area when True; see draw_emission_products().
    formats : tuple of str
        Output extensions, "png" and/or "pdf".
    allow_partial, titled : bool
        Permit diagnostic subsets; include standalone figure titles.
    image_downsample_factor : int
        Pixels summed along each image axis for display; default 1.

    Returns
    -------
    dict of str to list of pathlib.Path
        Written paths grouped as images, spectra, and gas_phases. The display
        window is +/-50 km/s; gas-phase comparisons use attenuated line spectra.

    Examples
    --------
    ``paths = plot_emission_products(products_dir, figure_dir, titled=True)``.
    To draw both versions, load_plot_products() once and call
    draw_emission_products() for each destination, as the plot command does.
    """
    products = load_plot_products(products_dir)
    return draw_emission_products(
        products=products,
        output_dir=output_dir,
        per_projected_area=per_projected_area,
        formats=formats,
        allow_partial=allow_partial,
        titled=titled,
        image_downsample_factor=image_downsample_factor,
    )


def prepare_temperature_component_spectra(payload: dict, projected_area_cm2):
    """Read one dust state's cold/hot profiles and choose luminosity units.

    Parameters
    ----------
    payload : dict of str to numpy.ndarray
        Numerical spectrum for one dust state: line_keys (L,), velocity_kms
        (V,) [km/s], and dL_dv_erg_s_per_kms (L, 2, V) [erg/s/(km/s)].
    projected_area_cm2 : float or None
        Optional projected area [cm^2] used to divide the plotted spectra.

    Returns
    -------
    keys : tuple of str, length L
        Line order in the input profiles.
    velocity : numpy.ndarray, shape (V,)
        Saved channel centres [km/s].
    spectra : numpy.ndarray, shape (L, 2, V)
        Cold/hot profiles in luminosity or surface-luminosity units.
    ylabel : str
        Axis label matching those units.
    """
    keys = tuple(str(key) for key in payload["line_keys"])
    velocity = np.asarray(payload["velocity_kms"])
    spectra = np.asarray(payload["dL_dv_erg_s_per_kms"])
    if projected_area_cm2 is not None:
        area = float(projected_area_cm2)
        spectra = spectra / area
        ylabel = r"$d\Sigma_L/dv$ [erg s$^{-1}$ cm$^{-2}$ (km s$^{-1}$)$^{-1}$]"
    else:
        ylabel = r"$dL/dv$ [erg s$^{-1}$ (km s$^{-1}$)$^{-1}$]"
    return keys, velocity, spectra, ylabel


def draw_temperature_component_profiles(axis, key, velocity_kms, cold_and_hot):
    """Draw one line's displayed total/cold/hot components with source labels.

    cold_and_hot has shape (2, V), with luminosity units selected by
    prepare_temperature_component_spectra(). Cold CIII/CIV and hot CO are
    omitted only from the display; their saved arrays are not modified.
    """
    total = cold_and_hot.sum(axis=0)
    cold_source = "DESPOTIC"
    if key in ("halpha", "hi21"):
        cold_source = "DESPOTIC + analytic"
    hot_source = "Cloudy"
    if key in ("co10", "co21"):
        hot_source = "DESPOTIC"
    for component, values, label, color, style, width in (
        ("total", total, "Total", "#161616", "-", 1.1),
        ("cold", cold_and_hot[0], r"$T_Q<3000$ K" + "\n" + cold_source,
         "#0072F5", "--", 1.9),
        ("hot", cold_and_hot[1], r"$T_Q\geq3000$ K" + "\n" + hot_source,
         "#E63946", ":", 2.0),
    ):
        if component == "total" and key.startswith(("ciii_", "civ_", "co")):
            continue
        if component == "cold" and key.startswith(("ciii_", "civ_")):
            continue
        # Hide the weak hot CO curve only in the display; saved data retain it.
        if component == "hot" and key in ("co10", "co21"):
            continue
        axis.plot(
            velocity_kms,
            values,
            label=label,
            color=color,
            ls=style,
            lw=width,
        )


def format_temperature_component_panel(axis, key, velocity_edges_kms):
    """Add one panel's title, limits, grid, and aligned multiline legend."""
    from matplotlib.offsetbox import DrawingArea, HPacker, TextArea

    axis.set_title(LINE_TITLES.get(key, key), fontsize=11)
    axis.ticklabel_format(axis="y", style="sci", scilimits=(-2, 2), useMathText=True)
    axis.set_ylim(bottom=0.)
    axis.grid(alpha=.18)
    axis.set_xlim(float(velocity_edges_kms[0]), float(velocity_edges_kms[-1]))
    legend = axis.legend(
        loc="upper right",
        fontsize=8,
        frameon=False,
        labelspacing=0.9,
        handletextpad=0.7,
    )
    for label in legend.get_texts():
        label.set_linespacing(1.05)
    # Align each line sample with the first (temperature) text line.
    for row in legend.findobj(HPacker):
        children = row.get_children()
        if (len(children) == 2 and isinstance(children[0], DrawingArea)
                and isinstance(children[1], TextArea)):
            row.align = "top"


def format_temperature_component_figure(figure, axes, line_count, ylabel, title):
    """Hide unused panels and add the shared velocity/luminosity labels and title."""
    for axis in list(axes.flat)[line_count:]:
        axis.set_visible(False)
    for axis in axes[-1]:
        if axis.get_visible():
            axis.set_xlabel(r"LOS velocity [km s$^{-1}$]")
    figure.supylabel(ylabel, fontsize=11)
    figure.suptitle(title, fontsize=13)
    figure.tight_layout(rect=(.025, 0., 1., .98))


def plot_temperature_component_spectra(
    payload,
    output_stem,
    *,
    projected_area_cm2=None,
    title="Adopted line spectra, LOS z",
):
    """Write a multi-panel figure of each line's temperature components.

    Parameters
    ----------
    payload : dict
        Numerical spectrum for one dust state:
        dL_dv_erg_s_per_kms (L, 2, V) [erg/s/(km/s)], velocity centres/edges
        [km/s], and line keys. L counts lines, V channels; regimes are cold, hot.
    output_stem : str or pathlib.Path
        Destination path without the PNG/PDF extension.
    projected_area_cm2 : float or None
        Optional area [cm^2] for converting spectra to surface luminosity.
    title : str
        Overall figure title.

    Returns
    -------
    dict of str to pathlib.Path
        Written paths keyed by "png" and "pdf".

    Examples
    --------
    With a single-dust-state spectral payload::

        paths = plot_temperature_component_spectra(payload, figure_dir / "components")
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    keys, velocity, spectra, ylabel = prepare_temperature_component_spectra(
        payload=payload,
        projected_area_cm2=projected_area_cm2,
    )
    rows = (len(keys) + 1) // 2
    figure, axes = plt.subplots(
        rows,
        2,
        figsize=(12, 2.6 * rows),
        squeeze=False,
        sharex=True,
    )
    priority = {key: rank for rank, key in enumerate(LINE_ORDER)}
    plot_indices = sorted(
        range(len(keys)),
        key=lambda index: priority.get(keys[index], len(priority)),
    )
    for line_index, axis in zip(plot_indices, axes.flat):
        key = keys[line_index]
        draw_temperature_component_profiles(
            axis=axis,
            key=key,
            velocity_kms=velocity,
            cold_and_hot=spectra[line_index],
        )
        format_temperature_component_panel(
            axis=axis,
            key=key,
            velocity_edges_kms=payload["velocity_edges_kms"],
        )
    format_temperature_component_figure(
        figure=figure,
        axes=axes,
        line_count=len(keys),
        ylabel=ylabel,
        title=title,
    )
    stem = Path(output_stem)
    stem.parent.mkdir(parents=True, exist_ok=True)
    paths = {}
    for extension in ("png", "pdf"):
        path = stem.with_suffix("." + extension)
        figure.savefig(path, dpi=180, bbox_inches="tight")
        paths[extension] = path
    plt.close(figure)
    return paths
