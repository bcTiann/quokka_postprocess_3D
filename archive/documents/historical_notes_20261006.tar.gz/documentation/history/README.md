# Historical workflow documentation

These documents preserve their full contents from before the 2026-10-03
readability cleanup. They preserve old commands, model decisions, comparisons,
and file locations; they are not the instructions for a new emission run.

| Archived document | Original location |
|---|---|
| [Root README](README_before_cleanup_20261003.md) | `README.md` |
| [Package README](package_README_before_cleanup_20261003.md) | `src/quokka2s/README.md` |
| [Default emission workflow](DEFAULT_EMISSION_WORKFLOW_before_cleanup_20261003.md) | `DEFAULT_EMISSION_WORKFLOW.md` |
| [Earlier Cloudy filtered-HM2012 workflow](CLOUDY_HM12_FILTERED_ISM_WORKFLOW.md) | `CLOUDY_HM12_FILTERED_ISM_WORKFLOW.md` |
| [Earlier Cloudy CII reproduction](CLOUDY_CII_REPRODUCTION.md) | `CLOUDY_CII_REPRODUCTION.md` |

Relative paths and relative links inside these verbatim copies refer to their
original locations. Their statements labelled "current" refer to the time
those sections were written; several sections describe different generations
of the pipeline. In particular, the older HDF5 task workflow, 300-channel
spectra without foreground dust, proposed abundance rescaling, and explicit
Cloudy depth-axis experiments are not the current emission configuration.
The two Cloudy documents describe earlier table experiments, including older
line selections, paths, and low-temperature Cloudy comparisons. They have been
moved here unchanged and are not guides to the current table-building setup.

Use the [current root README](../../README.md) for commands and data locations,
the [code guide](../../src/quokka2s/README.md) to follow `process` through `plot`,
and the [physics reference](../../DEFAULT_EMISSION_WORKFLOW.md) for the adopted
line branches and dust treatment. Standalone diagnostic scripts and shared
physical helpers remain available; archiving these instructions does not mean
all older analyses have been removed.

## Unused modules archived on 2026-10-04

[Source archive](unused_modules_20261004.tar.gz) contains seven retired modules
at their original repository paths, plus the original runner and table-I/O
tests as references. `archive_manifest.json` inside it records the reason for
each retirement and checksums for recovering the exact source.

- `pipeline/tasks/temperature_lext_diff.py`: no remaining caller or task registration.
- `pipeline/tasks/temperature_slices.py`, `temperature_projection.py`,
  `density_projection.py`, `temperature_compare.py`, and `table_diagnostics.py`:
  their historical runner registrations were already disabled. The unused
  imports and commented registrations were removed from that runner.
- `tables/augment_co21.py`: an old-table-only CO(2-1) replay tool. The current
  table solver calculates CO(1-0) and CO(2-1) together. Three tests specific to
  the retired tool are kept in the archive; general metadata and CO21
  save/load/lookup coverage remains in the active test suite.

The archive is historical source, not an installed package or supported command.
Current processing, plotting, table building, Figure 1, and phase-histogram
dependencies remain in `src/quokka2s`.

## Framework extraction and package layout, 2026-10-04

[Pre-migration source archive](framework_before_layout_20261004.tar.gz) preserves
all Python source, scripts and tests immediately before the directory migration.
It is for source recovery, not an import path or supported runtime mode.

Useful derived-field, hydrogen-emissivity, Figure 1, phase-histogram, and gas
projection code now lives in `physics/`, `products/`, and `figures/`. Table code
is grouped under `cloudy/` and `despotic/`. The old `pipeline/` Task/Context
registry, cache/HDF5 machinery, yt field registration, and dependent historical
experiment runners were removed from the live package. No forwarding aliases
were retained. Tests specific to those retired interfaces are preserved in the
archive; active physics and saved-product tests remain in `tests/`.

The kernel regression test reads frozen numerical reference data rather than
loading a retired plotting script. The reference file records its source hash.
The detailed retirement list is [framework_retired_files.json](framework_retired_files.json).
