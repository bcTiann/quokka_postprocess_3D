# Pipeline readability improvement plan

状态：2026-10-04 的可读性重构已完成；2026-10-06 的架构简化 goal 已完成实施与验收。当前源码、测试、数值和图像基线保存在 `output/pipeline_simplification_20261006/`。

接口与分支更新（2026-10-05）：已取消全局有效 cell mask，改为每条线的独立缺失判断；下面的 mask 方案已同步更新。当前查表入口为
`DespoticCellReader.read_fields()`、`CloudyCellReader.read_fields()`，每批计算入口为
`CellEmissionCalculator.calculate(cells=...)`。当前代码阅读说明见
[package README](../src/quokka2s/README.md)。

完整谱线矩与检查整理（2026-10-06）：已按用户确认，在同一次 batch 计算中累计完整 Gaussian 的光度、平均速度和二阶矩，另存 full/window centroid 与 sigma。400 通道仍为 ±200 km/s。当前绘图的谱线 sigma 图例使用 full 值，CO 黑线使用整盒冷热合计；检查集中在 process，plot 只读取绘图所需字段并处理显示选项。旧 `variant` 命名已改为 `dust_state`，不保留兼容别名。

本计划覆盖正在使用的 `process → 查表 → cell emissivity → image / spectrum / gas phase → 保存 → plot` 路径。按下面的阶段逐步实施、逐步核对结果。各阶段的名称是代码动作，不引入通用 Task、Context、mask registry 或兼容旧接口的转接层。

## 1. 实施顺序

| 阶段 | 需要完成的修改 | 完成后如何核对 |
|---|---|---|
| 1. mask 的含义与接口 | 采用第 2 节的方案：冷热分类独立于每条线的缺失判断；明确 table node、query、原始 batch 三种位置；删去互补和重复选择的存储 | 小型例子逐格核对；原有可用 cell 的数值不变，热原子线恢复被 DESPOTIC 误排除的 cell，CO 保留自身缺失 |
| 2. 统一名称 | `TableLookup → DespoticLookup`；`CloudyBatchFields → CloudyCellFields`；`query_cloudy_line_coefficients → query_cloudy_fields`；Cloudy 查询模块采用 `cell_fields.py`，与 DESPOTIC 对应；统一物理量与 intrinsic / attenuated 叫法 | 更新全部实际调用、导入、测试和阅读文档；不留下旧名称别名 |
| 3. 统一输入输出注释 | 公共阶段函数及结果类采用用户选定的 B 格式：类型、形状、单位、上游来源、具体例子；先纠正过时说明 | 注释逐项对照函数参数、返回字段、实际数组轴和调用位置 |
| 4. 整理底层查表 | DESPOTIC 的 broadcast / flatten / log / interpolation / reshape 共用清楚的动作；返回 T / CO 时写出字段名称；Cloudy 分开准备物理查询坐标和定位插值节点 | 保留当前插值方法、边界处理、失败节点权重规则、零值处理和查询顺序；比较真实 cell 查表结果 |
| 5. 整理 emissivity 转换 | `emissivity_per_nH2` 不再改称 `coefficients`；CO/CII lumPerH、粒子密度、物理 nH 与查表 nH 使用明确名称；写清前八行 Cloudy、末两行 CO 的顺序约定 | 各条线的 emissivity、NaN 位置、物理零、热展宽温度一致 |
| 6. 整理产品累计 | 图像分开 cell 光度计算和像素位置映射；光谱分开输入准备、epsilon×volume、冷热分支积分、累计更新；单份和双份光谱共用热展宽/积分计算 | 原生图像、光谱通道值、总光度、centroid、sigma、气相统计分别对比 |
| 7. 整理保存与绘图 | 内部统一 dust state、emissivity、luminosity、spectrum 等含义；读文件、选择曲线、计算显示统计、画图分成明确动作；避免为了调用绘图函数重建重复的多层字典 | process 保存的数据及 plot 图像与基线对比；存盘字段变更如确有必要，单独列出并同步修改写入/读取/测试 |
| 8. 完成阅读说明与验收 | 更新 package README 的实际阅读顺序和数据流；检查所有主线函数，而不只修正在聊天中点到的函数 | 检查无旧命名残留；完整相关测试与代表性 process/plot 对比完成后，报告修改及限制 |

以上八个阶段已完成；具体改动和验证限制见 [验收记录](pipeline_readability_validation.md)。

## 2. mask 整理方案

### 2.1 三种位置必须区分

- **table nodes**：表格网格上的位置，既不是 simulation cell，也不是当前 batch。
- **queries**：本次选出去查询的 Q 个位置。比如从 5 个 cell 中选 cell 1 和 cell 3，Q 就是 2。
- **cells**：当前 batch 原始 B 个 cell 的位置。查询结果放回后，所有 cell 数组都对应这个顺序。

名称规则：`*_nodes` 对应表节点，`*_queries` 对应选出的查询列表，`*_cells` 对应原始 batch。Q 每次查询可不同，必须在所在函数中定义；不能把它默认为最终有效 cell 数。

### 2.2 当前主线 cell mask

| 名称 | 对应位置/形状 | True 的含义 |
|---|---|---|
| `cold_cells` | 原始 batch，`(B,)` | `T_QUOKKA < 3000 K`，只表示温度分区 |
| `despotic_fields.invalid_temperature_cells` | 原始 batch，`(B,)` | DESPOTIC 温度无效；影响 CO 和需要它的冷原子线 |
| `cold_cells_to_query` | 原始 batch，`(B,)` | 冷 cell 且 DESPOTIC 温度可用；局部查询选择 |
| `hot_cells_to_query` | 原始 batch，`(B,)` | 全部热 cell，独立于 DESPOTIC |
| 底层 `failed_queries` | 已选查询，`(Q,)` | Cloudy 查询触及失败节点 |
| `cloudy_fields.failed_cells` | 原始 batch，`(B,)` | 这个热 cell 的 Cloudy 查询失败；不影响 CO |
| `line.emissivity_is_missing` | 原始 batch，`(B,)` | 这个 cell 缺少这条谱线的发射率；规定零值不是缺失 |

### 2.3 最终结果不再共享有效性 mask

`BatchEmission` 保存 `cold_cells`、DESPOTIC 温度和命名谱线结果，不保存全局 `valid_cells`。
每条 `LineEmission` 中的 NaN 只表示该条线缺失。`emissivity_is_missing` 从发射率数组派生，
不另外存储一张可能与数值不一致的 mask。图像与光谱都按这条线自己的可用性累计。

- 冷 CII、Halpha、HI：需要 DESPOTIC 的温度及相应字段。
- 热原子线：需要 Cloudy，不依赖 DESPOTIC。
- CO 两条线：所有温度都需要 DESPOTIC，包括展宽温度。
- 冷 CIII/CIV：规定为零，不依赖 DESPOTIC。
- Gas phase：冷 cell 用 DESPOTIC 温度，热 cell 用 QUOKKA 温度。

### 2.4 具体例子

| cell | 温度分区 | DESPOTIC | Cloudy | Halpha | CO | Gas phase |
|---|---|---|---|---|---|---|
| 0 | 冷 | 可用 | 不查询 | 可用 | 可用 | 用 DESPOTIC 温度 |
| 1 | 热 | 缺失 | 成功 | 可用 | 缺失 | 用 QUOKKA 温度 |
| 2 | 冷 | 缺失 | 不查询 | 缺失 | 缺失 | 缺失；冷 CIII/CIV 仍为规定零 |
| 3 | 热 | 可用 | 失败 | 缺失 | 可用 | 用 QUOKKA 温度 |

Cloudy 未查询位置的 `failed_cells=False` 不表示查询成功。只有实际查询的热 cell 才检查 Cloudy 结果。

### 2.5 表节点标记与插值标记留在查表模块

| 标记 | 作用 | 是否进入最终 BatchEmission |
|---|---|---|
| Cloudy 原表 `failure_mask` | 表节点计算失败；节点中的占位零不是物理零 | 否 |
| Cloudy 原表 `zero_mask` | 成功表节点的物理 emissivity 为零；决定采用线性值插值 | 否 |
| Cloudy `zero_support` | 当前某条线的查询用到了物理零节点，形状 `(L,Q)` | 否 |
| Cloudy `failure_touched` | 当前某条线的失败节点权重超过阈值，形状 `(L,Q)` | 否；合并各条线后形成 `failed_queries` |
| Cloudy `need_linear` / `need_log` | 哪些查询需要计算线性/对数插值结果 | 否 |
| DESPOTIC 原表 `failure_mask` | 记录原来哪些 equilibrium solve 失败 | 否；已填补节点仍保留该历史标记，运行时不能据此一律排除 |

其中 Cloudy `failure_weight` 是数值权重数组，不是布尔 mask。当前失败权重先相加再与 `1e-12` 比较；物理零节点按单个贡献权重与该阈值比较。整理名称不改这两个规则。

建议内存中的表节点名称采用 `failed_table_nodes` / `zero_emission_table_nodes`。磁盘上的已有字段如 `failure_mask` 与 `zero_mask` 属于 table 文件格式，不在局部改名时顺手修改。

### 2.6 截断标记用于统计

DESPOTIC 的 nH、NH、dVdr 截断标记各有 `(B,)` 个布尔值。它们只说明查询坐标有调整，不表示失败；Cloudy 的 NH 下界/上界截断同理。

推荐：

1. 查表及准备坐标时，在模块内部保留需要的逐 cell / query 标记。
2. DESPOTIC 统计温度可用查询的截断数量；Cloudy 统计成功热查询的 NH 截断数量。
3. `BatchEmission` 携带 `despotic_coordinate_clipped_cells = {'nH': count, 'NH': count, 'dVdr': count}`，替代当前三张完整的 `despotic_clipped` 数组。
4. Cloudy 继续携带 `{'below': count, 'above': count}`。

不能改变现有截断计数的边界比较规则。Cloudy 上层比较物理 NH，底层标记来自对数坐标；本次不互相替换。

### 2.7 图像与光谱的 mask 接口不同

**图像**按每条谱线自己的 `emissivity_is_missing` 选择原始 cell 位置，再映射到 x-y 像素；不再使用全局 `valid_cells`。

**光谱**按相同可用 cell 集合分组；同组谱线共用一组压缩的速度、温度和发射率数组。缺失集合不同的谱线分别累计，不把源数据的 NaN 改成物理零。

建议底层光谱接口直接接受已筛选的数据：

```python
line = emission.lines["halpha"]
available_cells = ~line.emissivity_is_missing      # (B,): Halpha only.
velocity_kms = cells.velocity_z_kms[available_cells]  # (R,)
cold_cells = emission.cold_cells[available_cells]  # (R,)
```

这里 R 是这条线的可用 cell 数。底层使用压缩后的 `cold_cells` 区分冷热分支，保留规定零值的计数。存盘的 `cell_counts_by_regime` 为 `(Nline, 2)`。

气相统计使用混合温度自己的可用性；DESPOTIC 失败不排除使用 QUOKKA 温度的热气体。速度窗口和零光度跳过计算的标记继续留在对应算法内部。

## 3. 名称与注释规范

- 类名称表示所存内容：`DespoticCellFields` / `CloudyCellFields` 对应按原始 batch 位置排列的查表结果。
- 函数名称表达动作：读取/查询、转换、积分、累计、保存、绘图各用明确动词。
- 同一物理量跨函数传递时保留同一名称。`emissivity_per_nH2`、`co10_luminosity_per_H`、`electron_density_cm3` 等不在下一层改成泛称。
- 每条谱线的发射率与采用状态的温度一起计算、一起返回：`IntrinsicLineEmission` 保存 `emissivity_erg_s_cm3` 和 `temperature_K`。Dust 后得到 `LineEmission`，保留同一个 `temperature_K` 用于展宽；不再额外按谱线重复选择温度来源。
- Halpha/HI/CII、CIII/CIV、CO 分成三个具名计算动作。组名描述谱线本身，例如 `CIII_CIV_LINE_KEYS`，不把“冷气体发射率为零”这个行为名称用作温度计算的谱线名称。
- 区分物理 `hydrogen_density_cm3` 与截断后的 `query_hydrogen_density_cm3`。
- 公共函数/结果类采用 B 格式英文 docstring；列表中的每个参数写类型、形状、单位、来源和必要的例子。
- 例子展示实际索引或数值；不能把 `(10, 2, 400)` 的 shape 写成访问索引。
- 注释根据当前实现说明 `NaN`、物理零、未查询位置、有效位置；不指向已归档的脚本来替代说明。
- 多参数调用、对象构造和关键赋值展开写；拆函数依据动作意义，不按行数机械拆分。
- 每个 result 类的详细字段说明写在类上；函数说明其实际用到的字段和来源，避免复制多份容易过时的完整说明。

## 4. 实施与验证边界

- 本轮修改运行代码与阅读文档；论文未修改。
- 每次实施前冻结当前工作区源码作为基线，保留当前已有的未提交修改；不能用 Git HEAD 代替当前源码。
- 内部接口改名需同步实际调用者、脚本和测试，不保留旧名字的兼容别名。
- 删除全局有效性 mask 后，核对每条线的依赖关系。原来保留的 cell 数值应不变；热原子线恢复被 DESPOTIC 误排除的 cell，CO 保留自身缺失。
- 除修正跨谱线的全局排除逻辑外，不改科学组成、3000 K 分区、表格插值、零值/NaN 规则、dust 路径、100 pc 上限、图像原生分辨率、400 通道或气相边界。
- 不把 DESPOTIC 其他字段的报错改成自动排除；不改变 diagnostics 的独立选择规则。
- 首先跑对应模块的测试；接口阶段完成后跑当前相关完整测试。记录当前基线的失败项，并与新增回归分开报告。
- 使用覆盖冷热 cell 和空间边界的真实数据，比较物理数组与代表性 process 产品；涉及绘图时再比较 PNG/PDF。全部阶段完成后安排一次完整 snapshot 的 process/plot 验收，避免每个局部注释修改都重跑整盒。
- 提交/推送作为用户确认后的独立步骤；本计划不代表已经提交或推送。

## 5. 本轮验收与后续

- 当前 `BatchEmission` 只保留温度分区 `cold_cells`；每条线从自身数组派生缺失判断，DESPOTIC 截断记录仍只携带计数。
- Cloudy/DESPOTIC 查表类和结果类名称已统一，调用者与测试已同步；未保留旧名称别名。
- 图像、光谱、气相、保存及绘图使用分开的语义动作与有明确字段的数据对象。
- 下列数值/图像验收是 2026-10-04 的可读性重构记录；2026-10-05 的独立谱线选择验证单独保存在 `output/independent_line_masks_20261005/`。
- 2026-10-04：原生 image、400 通道 spectrum、整盒 sigma 和气相数据的 47 个保存字段与冻结基线精确相同。
- 78 张 PNG 精确相同；78 份 PDF 除生成时间元数据外内容相同。
- 360 项测试前后均为 358 通过、2 项既有失败，无新增失败或丢失测试。中断 checkpoint 测试的具体文件列表随时间竞争而变化，未把它记录为通过。
- 详细记录与独立于主线的后续问题见 [验收记录](pipeline_readability_validation.md)。提交/推送仍是单独步骤。

### 2026-10-05：独立谱线缺失判断的验收

- 完整处理 134,217,728 个 cell，用时约 10 分钟；八条原子线没有缺失，两条 CO 各缺失 19,827 个 cell。Gas phase 使用全部 cell。
- 对 1,572,864 个真实 cell 作同输入对比：原来可用的 intrinsic/attenuated 发射率逐值相同，非零发射对应的展宽温度相同；热原子线恢复了原来被 DESPOTIC 全局 mask 误排除的位置。
- 完整输出的 spectrum 与独立 cell 光度求和最大相对差为 `1.03755e-12`；image 为 `5.60243e-15`。求和校验统一采用 `rtol=1e-10, atol=0`，零光度仍严格检查。
- 243 项测试通过；未改动的 DESPOTIC checkpoint 中断测试存在既有并发竞争，单独记录，不记作通过。
- 已重新生成无标题和带标题两套图，各 39 张 PNG 和 39 份 PDF；抽查了光度 image、Halpha spectrum 和 CO gas-phase 对比图。
- 默认 process/plot 配置已切到 `output/plt0655228/processed_independent_lines_20261005/`；旧数值结果保留。
- 真实 cell 对比、独立查表审计、守恒误差和测试记录分别保存在 `output/independent_line_masks_20261005/` 与 `output/branch_lookup_audit_20261005/`。

### 2026-10-05：发射率与温度一同计算的验收

- 三组谱线计算同时返回发射率和对应气体温度，删除单独的 `select_broadening_temperatures()`；后续读取 `line.temperature_K`。
- Cloudy 返回实际用于查询的温度，DESPOTIC 返回平衡温度；dust 保留对应温度数组，不再重新判定来源。
- 82 项相关测试通过，包括查询后不重复查表、温度来源、空批次、谱线重排、独立缺失值和产品累计。
- 冻结当前源码作基线，在 x=0、128、255 共 1,572,864 个真实 cell 上对比：发射率、dust 发射率、温度（包括零发射位置）、NaN 与缺失标记逐值相同。
- 这些 cell 累计得到的 image、spectrum、centroid、sigma、gas-phase 数据及报告逐值相同，守恒检查通过。没有重跑完整 snapshot，也没有修改存盘格式或绘图选项。
- 验证记录保存在 `output/line_state_refactor_20261005/`；本轮未提交、推送或修改论文。

### 2026-10-06：完整谱线矩与 process/plot 检查

- `LineVelocityMoments` 累计每条线、每种 dust 状态的完整光度和速度矩。热宽与通道积分共用同一次计算；合并 batch 时计入各批 centroid 的差。
- process 保留独立 cell/image/spectrum 光度守恒、通道积分、有限物理结果、dust 衰减、冷 CIII/CIV 零值和气相统计。删除 plot 的固定 shape、400 通道、坐标轴、有限性及重复守恒检查；显示选项检查仍由 plot 处理。
- 1,572,864 个真实 cell 的旧发射率、温度、缺失位置及产品逐值相同。新增完整矩与独立计算核对；另有 Gaussian 积分、远超窗口速度、并行合并和大共同速度偏移测试。
- 整盒 134,217,728 个 cell 重算完成，耗时 545 秒。旧原生 image、400 通道 spectrum、gas phase、window centroid/sigma 全部精确相同；78 张正式 PNG 与冻结基线逐像素一致。
- 249 项测试通过。既有 DESPOTIC checkpoint 中断竞争测试单独保留，未纳入本轮；该模块源码与冻结基线一致。
- 新数值产品：`output/plt0655228/processed_full_line_moments_20261006/`。比较证据：`output/full_line_moments_20261006/`。默认 process/plot 配置已指向新结果，论文未修改。
- full 与 window 的差包括速度窗口和通道中心离散近似两部分；full sigma 不要求一定大于 window。新版 dust CIV 1548 的 sigma 从 63.23256 增至 64.68959 km/s（+2.30423%）。

### 2026-10-06：图例采用完整 sigma

- 用户确认 CO 黑线也使用整盒冷热合计光谱，使其与完整 sigma 的光度权重一致。其他谱线的显示分支不变；CIII/CIV 冷发射严格为零，因此 hot 与 total 一致。
- 所有谱线图例读取 `line_sigma_full_kms`，不再从保存的窗口内通道重新计算 sigma；速度轴和气相 sigma 未变。此次只运行 plot，未重算 process。
- 两套图各 39 张 PNG 和 39 份 PDF 已重新生成。九项相关测试通过，十条实际图例均与保存的完整 sigma 核对；其余 58 张 image/spectrum PNG 与改图例前逐像素相同。
- 绘图前源码、PNG 和验收记录保存在 `output/plot_full_sigma_20261006/`。

### 2026-10-06：独立入口与单一光谱累计流程

本轮 goal 按以下顺序实施：

1. 冻结当前工作区源码、已有完整产品与两套图作为基线，保留未提交修改。
2. process、plot 使用各自的模块入口与 YAML；移除统一命令分派，不保留旧入口别名。
3. `IntegratedSpectra` 直接累计两种 dust 状态、每条线和冷热分支；只保留生产使用的 `add_batch()`。
4. 删除临时光谱累计对象、重复拼装 dust 输出、空包装函数和仅测试需要的可变 cell 体积接口。
5. 保留语义明确的对象与动作、独立缺失判断、Gaussian 共用、完整矩、有界并行及 slab 内存释放。
6. 更新真实调用者、测试与阅读文档。英文注释保留输入来源、形状、单位和具体例子，避免重复长篇调用说明。
7. 检查实际 cell 的发射率与温度，比较累计产品，再运行完整 process/plot，与冻结基线逐字段、逐像素核对。

本轮不修改组成、插值、温度分支、dust、速度通道、图形显示规则或论文。

本轮验收完成：

- process、plot 使用独立入口：`python -m quokka2s.process_snapshot`、`python -m quokka2s.plot_emission_results`，各自读取 `--config` 指定的 YAML。
- 光谱累计模块从 1166 行整理为 614 行；不再构造两套单独的光谱累计器或临时累计器。`IntegratedSpectra` 直接持有两种 dust 状态的光谱、输入光度、计数和完整矩。
- 输入加载、处理调度和保存移除重复说明与空包装，保留语义阶段、English shape/unit comments、有界队列、按输入顺序合并和每个 slab 完成后的释放。
- 修改前同一套测试 249 项通过；修改后 251 项通过，增加了两个入口隔离测试。三个旧测试名称更新为生产入口/独立 Gaussian kernel 的验证，科学覆盖保留。另有三个气相绘图函数测试通过。
- 既有 DESPOTIC checkpoint 中断竞争测试单独保留、未计作通过；该模块源码未修改。
- x=0、128、255 共 1,572,864 个真实 cell 的发射率、温度、NaN 位置及累计产品共 83 个字段精确相同。
- 完整处理 134,217,728 个 cell，耗时约 577 秒；新旧三份 NPZ 的 53 个字段精确相同，科学报告除时间字段外精确相同。
- 两套图均重新生成：78 张 PNG 逐像素一致；78 份 PDF 除生成时间元数据外全部字节一致。
- 新结果：`output/plt0655228/processed_simplified_20261006/`，两个 YAML 均已切到此路径。图仍输出到 `output/plt0655228/figures/` 和 `figures_titled/`。
- 源码基线、测试、实际 cell 对比、完整重算日志与绘图比较均位于 `output/pipeline_simplification_20261006/`；阅读路径见 package README。本轮论文未改动，未提交或推送。
